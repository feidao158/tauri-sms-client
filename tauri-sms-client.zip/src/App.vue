<script setup>
  import {ref} from "vue";

  const loginStatus = ref(false)
</script>

<template>
  <div>
    <RouterView/>
  </div>
</template>

<style scoped>

</style>
