<script setup>

</script>

<template>
  <div>
    business page
  </div>
</template>

<style scoped lang="scss">

</style>
